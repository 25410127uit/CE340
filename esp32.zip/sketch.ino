#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// GPIO khớp với slide báo cáo
#define PIR_PIN     13
#define RELAY_PIN   12
#define LED_GREEN   14
#define LED_RED     15
#define OLED_SDA    21
#define OLED_SCL    22

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET   -1

const char* ssid        = "Wokwi-GUEST";
const char* password    = "";

const char* mqtt_server = "44664d8119b54fadaf9870a37274af6b.s1.eu.hivemq.cloud";
const int   mqtt_port   = 8883;

// Không hardcode mật khẩu thật trong file nộp báo cáo.
// Điền user/pass HiveMQ Cloud của nhóm trước khi demo.
const char* mqtt_user   = "YOUR_MQTT_USER";
const char* mqtt_pass   = "YOUR_MQTT_PASSWORD";

const char* topicTrigger = "diemdanh/camera/trigger";
const char* topicRelay   = "diemdanh/relay/control";
const char* topicResult  = "diemdanh/ketqua";

const unsigned long PIR_WARMUP_MS     = 3000;
const unsigned long PUBLISH_COOLDOWN  = 5000;
const unsigned long RELAY_OPEN_MS     = 5000;

unsigned long startTime = 0;
unsigned long lastPublish = 0;
unsigned long relayOpenedAt = 0;
bool relayOpen = false;
int lastMotionState = LOW;

WiFiClientSecure espClient;
PubSubClient client(espClient);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void showOLED(const String& line1, const String& line2 = "") {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("AIoT Diem Danh");
  display.println("--------------");
  display.println(line1);
  if (line2.length()) display.println(line2);
  display.display();
}

void setRelay(bool open) {
  relayOpen = open;
  digitalWrite(RELAY_PIN, open ? HIGH : LOW);
  digitalWrite(LED_GREEN, open ? HIGH : LOW);
  if (open) relayOpenedAt = millis();
}

void blinkRed(int times = 3) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_RED, HIGH); delay(180);
    digitalWrite(LED_RED, LOW);  delay(180);
  }
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  msg.trim();

  Serial.print("[MQTT] ");
  Serial.print(topic);
  Serial.print(" => ");
  Serial.println(msg);

  String topicStr(topic);
  if (topicStr == topicRelay) {
    if (msg == "OPEN_DOOR") {
      setRelay(true);
      showOLED("ACCESS GRANTED", "Relay OPEN");
    } else if (msg == "CLOSE_DOOR") {
      setRelay(false);
      showOLED("Door closed", "Waiting...");
    } else if (msg == "DENY") {
      setRelay(false);
      showOLED("ACCESS DENIED", "Unknown face");
      blinkRed();
    }
  } else if (topicStr == topicResult) {
    if (msg.startsWith("PRESENT:")) {
      showOLED("Recognized:", msg.substring(8));
    } else {
      showOLED("Result:", msg);
    }
  }
}

void setupWiFi() {
  WiFi.begin(ssid, password);
  Serial.print("[WiFi] Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" connected");
}

void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("[MQTT] Connecting...");
    String clientId = "ESP32_AIOT_" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
      Serial.println(" connected");
      client.subscribe(topicRelay);
      client.subscribe(topicResult);
      showOLED("MQTT connected", "Waiting PIR...");
    } else {
      Serial.print(" failed, rc=");
      Serial.println(client.state());
      showOLED("MQTT failed", "Check user/pass");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED, OUTPUT);

  digitalWrite(RELAY_PIN, LOW);
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_RED, LOW);

  Wire.begin(OLED_SDA, OLED_SCL);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  showOLED("Booting...");

  setupWiFi();
  espClient.setInsecure();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(onMessage);
  reconnectMQTT();

  startTime = millis();
  Serial.println("[SYS] PIR warmup...");
  showOLED("PIR warmup", "Please wait...");
}

void loop() {
  if (!client.connected()) reconnectMQTT();
  client.loop();

  if (millis() - startTime < PIR_WARMUP_MS) return;

  int motion = digitalRead(PIR_PIN);
  unsigned long now = millis();

  if (motion == HIGH && now - lastPublish >= PUBLISH_COOLDOWN) {
    lastPublish = now;
    client.publish(topicTrigger, "PERSON_DETECTED");
    Serial.println("[PIR] PERSON_DETECTED published");
    showOLED("PIR detected", "AI processing...");
  }

  if (relayOpen && now - relayOpenedAt >= RELAY_OPEN_MS) {
    setRelay(false);
    showOLED("Auto close", "Waiting...");
  }

  if (motion != lastMotionState) {
    Serial.println(motion == HIGH ? "[PIR] Motion HIGH" : "[PIR] Motion LOW");
    lastMotionState = motion;
  }

  delay(50);
}
